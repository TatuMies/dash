# CL9 Dash

OBD2 dashboard for a Honda Accord CL9 (K24A3) as an Android app.

- `app/src/main/assets/index.html` — the dashboard itself (also runs on its own in Chrome).
- `app/src/main/java/fi/tatu/cl9dash/` — the Android side:
  - `MainActivity.kt` — fullscreen landscape WebView that loads the dashboard.
  - `ObdBridge.kt` — Bluetooth link to the ELM327 adapter (BLE and Classic).
  - `MediaBridge.kt` — music widget: reads and controls the current music player.

## Building

Every push to `main` builds the app on GitHub (see the **Actions** tab). The APK is
attached to a new entry under **Releases**. Download it on the phone and install it.

## First run on the phone

1. Allow installing apps from your browser / files app when Android asks.
2. Tap **CONNECT** and allow Bluetooth access. Pick your adapter from the list; it is
   remembered next time. (Settings → FORGET ADAPTER to pick another one.)
3. For the music widget: tap the note icon, then **ALLOW ACCESS**, and enable
   *CL9 Dash media*. On Android 13+ the switch may be greyed out for apps installed
   outside the Play Store: open the app's *App info* → ⋮ menu → *Allow restricted
   settings*, then try again.
