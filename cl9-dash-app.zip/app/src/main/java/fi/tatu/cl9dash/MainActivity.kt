package fi.tatu.cl9dash

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Hosts the dashboard (assets/index.html) full-screen in landscape and exposes the
 * "AndroidOBD" bridge the page uses for Bluetooth OBD and media control.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var obd: ObdBridge
    private lateinit var media: MediaBridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // the page saves settings in localStorage
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }
        WebView.setWebContentsDebuggingEnabled(true)   // lets chrome://inspect on a PC see the page
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()

        obd = ObdBridge(this, web)
        media = MediaBridge(this, web)
        web.addJavascriptInterface(Bridge(), "AndroidOBD")
        web.loadUrl("file:///android_asset/index.html")
        hideSystemBars()
    }

    /** Methods callable from the page as AndroidOBD.xxx(). They run on a background thread. */
    inner class Bridge {
        @JavascriptInterface fun connect() { obd.connect() }
        @JavascriptInterface fun write(s: String) { obd.write(s) }
        @JavascriptInterface fun disconnect() { obd.disconnect() }
        @JavascriptInterface fun forgetAdapter() { obd.forgetAdapter() }
        @JavascriptInterface fun media(cmd: String) { media.command(cmd) }
        @JavascriptInterface fun mediaRefresh() { media.refresh() }
        @JavascriptInterface fun mediaPermission() { media.openPermissionSettings() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == ObdBridge.REQ_PERMS) {
            obd.onPermissionResult(grantResults.isNotEmpty() && grantResults.all { it == android.content.pm.PackageManager.PERMISSION_GRANTED })
        }
    }

    override fun onResume() { super.onResume(); hideSystemBars(); media.start() }
    override fun onPause() { media.stop(); super.onPause() }
    override fun onDestroy() { obd.disconnect(); web.destroy(); super.onDestroy() }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }
}
