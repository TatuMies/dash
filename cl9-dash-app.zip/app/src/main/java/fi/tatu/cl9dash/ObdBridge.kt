package fi.tatu.cl9dash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.widget.ArrayAdapter
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Bluetooth link to the ELM327 adapter, for the page's native bridge.
 * Supports both BLE adapters (GATT serial) and Classic Bluetooth (SPP) adapters.
 *
 * Page -> native:  connect(), write(text), disconnect(), forgetAdapter()
 * Native -> page:  OBD.onData(text), OBD.onStatus("connected" | "disconnected" | "error:<msg>")
 *
 * The last adapter that connected is remembered and tried first; if that fails,
 * a picker lists paired devices plus BLE adapters found by a short scan.
 */
@SuppressLint("MissingPermission")   // permissions are checked in connect() before any Bluetooth call
class ObdBridge(private val act: Activity, private val web: WebView) {

    companion object {
        const val REQ_PERMS = 42
        private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        // Common ELM327 BLE serial services, tried before any other service.
        private val KNOWN_SVCS = listOf(
            "0000fff0-0000-1000-8000-00805f9b34fb", "0000ffe0-0000-1000-8000-00805f9b34fb",
            "000018f0-0000-1000-8000-00805f9b34fb", "e7810a71-73ae-499d-8c15-faa9aef0c3f2",
            "6e400001-b5a3-f393-e0a9-e50e24dcca9e", "0000ffe5-0000-1000-8000-00805f9b34fb"
        ).map { UUID.fromString(it) }
    }

    private interface Link { fun write(s: String); fun close() }

    private val main = Handler(Looper.getMainLooper())
    private val prefs = act.getSharedPreferences("obd", Context.MODE_PRIVATE)
    private val adapter: BluetoothAdapter?
        get() = (act.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var link: Link? = null
    private var pendingConnect = false

    // ───────────────────────── called from the page ─────────────────────────

    fun connect() {
        main.post {
            if (!hasPerms()) { pendingConnect = true; act.requestPermissions(perms(), REQ_PERMS); return@post }
            val a = adapter
            if (a == null) { status("error:No Bluetooth on this phone"); return@post }
            if (!a.isEnabled) { status("error:Bluetooth is turned off"); return@post }
            val addr = prefs.getString("addr", null)
            val mode = prefs.getString("mode", null)
            if (addr != null && mode != null) open(a.getRemoteDevice(addr), mode, pickerOnFail = true)
            else showPicker(a)
        }
    }

    fun write(s: String) { main.post { link?.write(s) } }

    fun disconnect() { main.post { link?.close(); link = null } }

    fun forgetAdapter() { prefs.edit().clear().apply() }

    fun onPermissionResult(granted: Boolean) {
        if (!pendingConnect) return
        pendingConnect = false
        if (granted) connect() else status("error:Bluetooth permission denied")
    }

    // ───────────────────────── helpers ─────────────────────────

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun hasPerms() = perms().all { act.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun js(code: String) { main.post { web.evaluateJavascript(code, null) } }
    private fun data(s: String) = js("window.OBD&&window.OBD.onData&&window.OBD.onData(${JSONObject.quote(s)})")
    private fun status(s: String) = js("window.OBD&&window.OBD.onStatus&&window.OBD.onStatus(${JSONObject.quote(s)})")
    private fun lost() { main.post { link = null; status("disconnected") } }

    private fun showPicker(a: BluetoothAdapter) {
        val items = ArrayList<Pair<BluetoothDevice, String>>()          // device, "spp" | "ble"
        val labels = ArrayAdapter<String>(act, android.R.layout.simple_list_item_1, ArrayList())
        fun add(d: BluetoothDevice, name: String?, mode: String, tag: String) {
            if (items.any { it.first.address == d.address && it.second == mode }) return
            items.add(d to mode)
            labels.add("${name ?: "Unknown device"}   ·   $tag\n${d.address}")
        }
        a.bondedDevices?.forEach { d ->
            if (d.type == BluetoothDevice.DEVICE_TYPE_LE) add(d, d.name, "ble", "paired, BLE")
            else add(d, d.name, "spp", "paired, Classic")
        }
        val scanner = a.bluetoothLeScanner
        val scanCb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, r: ScanResult) {
                val name = r.device.name ?: r.scanRecord?.deviceName ?: return   // skip nameless beacons
                main.post { add(r.device, name, "ble", "BLE") }
            }
        }
        val stopScan = { try { scanner?.stopScan(scanCb) } catch (_: Exception) { } }
        var chosen = false
        val dlg = AlertDialog.Builder(act)
            .setTitle("Choose OBD adapter")
            .setAdapter(labels) { _, i -> chosen = true; val (d, m) = items[i]; open(d, m, pickerOnFail = false) }
            .setNegativeButton("Cancel", null)
            .create()
        dlg.setOnDismissListener { stopScan(); if (!chosen) status("error:cancelled") }
        dlg.show()
        try { scanner?.startScan(scanCb); main.postDelayed({ stopScan() }, 10000) } catch (_: Exception) { }
    }

    private fun open(d: BluetoothDevice, mode: String, pickerOnFail: Boolean) {
        link?.close(); link = null
        val onOpen = {
            prefs.edit().putString("addr", d.address).putString("mode", mode).apply()
            status("connected")
        }
        val onFail = { msg: String ->
            link = null
            val a = adapter
            if (pickerOnFail && a != null) showPicker(a) else status("error:$msg")
        }
        link = if (mode == "spp") SppLink(d, onOpen, onFail) else BleLink(d, onOpen, onFail)
    }

    // ───────────────────────── Classic Bluetooth (SPP) ─────────────────────────

    private inner class SppLink(dev: BluetoothDevice, onOpen: () -> Unit, onFail: (String) -> Unit) : Link {
        @Volatile private var sock: BluetoothSocket? = null
        @Volatile private var closed = false
        private val writer = Executors.newSingleThreadExecutor()

        init {
            Thread {
                try {
                    adapter?.cancelDiscovery()
                    val s = try {
                        dev.createRfcommSocketToServiceRecord(SPP).also { it.connect() }
                    } catch (e: Exception) {
                        dev.createInsecureRfcommSocketToServiceRecord(SPP).also { it.connect() }
                    }
                    if (closed) { s.close(); return@Thread }
                    sock = s
                    main.post { onOpen() }
                    val input = s.inputStream
                    val buf = ByteArray(1024)
                    while (!closed) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) data(String(buf, 0, n, Charsets.ISO_8859_1))
                    }
                } catch (e: Exception) {
                    if (!closed && sock == null) main.post { onFail(e.message ?: "connection failed") }
                }
                if (!closed && sock != null) lost()
            }.start()
        }

        override fun write(s: String) {
            val so = sock ?: return
            writer.execute {
                try { so.outputStream.write(s.toByteArray(Charsets.ISO_8859_1)); so.outputStream.flush() } catch (_: Exception) { }
            }
        }

        override fun close() {
            closed = true
            try { sock?.close() } catch (_: Exception) { }
            writer.shutdownNow()
        }
    }

    // ───────────────────────── Bluetooth LE (GATT serial) ─────────────────────────

    private inner class BleLink(dev: BluetoothDevice, private val onOpen: () -> Unit, private val onFail: (String) -> Unit) : Link {
        private var gatt: BluetoothGatt? = null
        private var tx: BluetoothGattCharacteristic? = null
        private val queue = ArrayDeque<ByteArray>()
        private var busy = false
        private var opened = false
        private var closed = false

        private val cb = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, st: Int, newState: Int) {
                main.post {
                    if (closed) return@post
                    if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
                    else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        g.close()
                        if (opened) lost() else onFail("BLE connection failed ($st)")
                    }
                }
            }
            override fun onServicesDiscovered(g: BluetoothGatt, st: Int) { main.post { if (!closed) setup(g) } }
            override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, st: Int) {
                main.post { if (!opened && !closed) { opened = true; onOpen() } }
            }
            override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, st: Int) {
                main.post { busy = false; pump() }
            }
            // Android 13+
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
                data(String(value, Charsets.ISO_8859_1))
            }
            // Android 12 and older
            @Deprecated("Deprecated in Java")
            @Suppress("DEPRECATION")
            override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
                if (Build.VERSION.SDK_INT < 33) data(String(c.value ?: return, Charsets.ISO_8859_1))
            }
        }

        init { gatt = dev.connectGatt(act, false, cb, BluetoothDevice.TRANSPORT_LE) }

        @Suppress("DEPRECATION")
        private fun setup(g: BluetoothGatt) {
            val svcs = g.services.sortedBy { s -> KNOWN_SVCS.indexOf(s.uuid).let { if (it < 0) 99 else it } }
            for (s in svcs) {
                val rx = s.characteristics.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 }
                    ?: s.characteristics.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0 }
                val w = s.characteristics.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0 }
                    ?: s.characteristics.firstOrNull { it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 }
                if (rx == null || w == null) continue
                tx = w
                g.setCharacteristicNotification(rx, true)
                val desc = rx.getDescriptor(CCCD)
                if (desc == null) { opened = true; onOpen(); return }
                val v = if (rx.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0)
                    BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(desc, v)
                else { desc.value = v; g.writeDescriptor(desc) }
                return
            }
            onFail("No serial characteristic on this BLE device")
            close()
        }

        override fun write(s: String) {
            val b = s.toByteArray(Charsets.ISO_8859_1)
            var i = 0
            while (i < b.size) { queue.addLast(b.copyOfRange(i, minOf(i + 20, b.size))); i += 20 }
            pump()
        }

        /** BLE allows one write in flight at a time; the next chunk goes out on onCharacteristicWrite. */
        @Suppress("DEPRECATION")
        private fun pump() {
            if (busy || closed) return
            val g = gatt ?: return
            val c = tx ?: return
            val chunk = queue.removeFirstOrNull() ?: return
            val type = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, chunk, type) == BluetoothGatt.GATT_SUCCESS
            } else {
                c.writeType = type; c.value = chunk; g.writeCharacteristic(c)
            }
            if (ok) busy = true
            else { queue.addFirst(chunk); main.postDelayed({ pump() }, 15) }   // stack busy: retry shortly
        }

        override fun close() {
            closed = true
            queue.clear()
            try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) { }
            gatt = null
        }
    }
}
