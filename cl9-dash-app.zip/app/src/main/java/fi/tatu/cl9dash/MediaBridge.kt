package fi.tatu.cl9dash

/*
 * MediaBridge — feeds the dashboard's music widget from Android's media sessions
 * (works with any player that shows lock-screen controls: Spotify, YouTube Music, …).
 * Needs "notification access" for this app, which the page asks for when missing.
 */

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.util.Base64
import android.webkit.WebView
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/** Intentionally empty. It exists only so the user can grant "notification access",
 *  which Android requires before an app may read other apps' media sessions. */
class MediaListener : NotificationListenerService()

class MediaBridge(private val activity: Activity, private val web: WebView) {

    private val main = Handler(Looper.getMainLooper())
    private val msm = activity.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerName = ComponentName(activity, MediaListener::class.java)
    private var controller: MediaController? = null
    private var listening = false
    private var lastArtKey: String? = null

    private val sessionsChanged =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
        override fun onSessionDestroyed() = pick(sessions())
    }

    fun hasPermission(): Boolean {
        val enabled = Settings.Secure.getString(activity.contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it)?.packageName == activity.packageName }
    }

    /** Call from onResume (also re-checks permission after the user returns from Settings). */
    fun start() {
        if (!hasPermission()) { send(JSONObject().put("needsPermission", true)); return }
        if (!listening) {
            try {
                msm.addOnActiveSessionsChangedListener(sessionsChanged, listenerName, main)
                listening = true
            } catch (_: SecurityException) { }
        }
        lastArtKey = null          // force art to be re-sent (page may have reloaded)
        pick(sessions())
    }

    /** Call from onPause. */
    fun stop() {
        if (listening) {
            try { msm.removeOnActiveSessionsChangedListener(sessionsChanged) } catch (_: Exception) { }
            listening = false
        }
        controller?.unregisterCallback(callback)
        controller = null
    }

    // ── called from JavaScript (JS-interface methods run on a background thread → hop to main) ──

    fun command(cmd: String) {
        main.post {
            val c = controller ?: return@post
            val t = c.transportControls
            when (cmd) {
                "next" -> t.skipToNext()
                "prev" -> t.skipToPrevious()
                "toggle" -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
            }
        }
    }

    fun refresh() { main.post { start() } }

    fun openPermissionSettings() {
        main.post { activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }

    // ── internals ──

    private fun sessions(): List<MediaController> =
        try { msm.getActiveSessions(listenerName) } catch (_: SecurityException) { emptyList() }

    /** Prefer whichever player is actually playing; otherwise the most recent session. */
    private fun pick(list: List<MediaController>?) {
        val l = list ?: emptyList()
        val next = l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull()
        if (next?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = next
            next?.registerCallback(callback, main)
            lastArtKey = null
        }
        push()
    }

    private fun push() {
        val c = controller
        val o = JSONObject()
        if (c == null) {
            send(o.put("title", "").put("artist", "").put("playing", false).put("art", ""))
            lastArtKey = null
            return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        o.put("title", title).put("artist", artist).put("app", c.packageName)
            .put("playing", c.playbackState?.state == PlaybackState.STATE_PLAYING)

        // Art is only sent when it changes (it's the heavy part). Some players deliver the
        // bitmap in a later metadata update, so "has bitmap" is part of the key.
        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val key = "${c.packageName}|$title|$artist|${md?.getString(MediaMetadata.METADATA_KEY_ALBUM)}|${bmp != null}"
        if (key != lastArtKey) {
            lastArtKey = key
            o.put("art", bmp?.let { toDataUrl(it) } ?: "")
        }
        send(o)
    }

    private fun toDataUrl(src: Bitmap): String {
        val max = 300
        val scale = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        val b = if (scale < 1f)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        else src
        val out = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun send(o: JSONObject) {
        val js = "window.OBD&&window.OBD.onMedia&&window.OBD.onMedia($o)"
        main.post { web.evaluateJavascript(js, null) }
    }
}
